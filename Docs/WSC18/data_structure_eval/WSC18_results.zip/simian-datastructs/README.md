#SimianPie

This directory contains stable branch of SimianPie (Python) source which uses CTypes to interface with MPI libraries (currently only MPICH 3.1.4 is tested).
