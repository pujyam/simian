#!/bin/bash
rm *~ *.pyc *# *.out